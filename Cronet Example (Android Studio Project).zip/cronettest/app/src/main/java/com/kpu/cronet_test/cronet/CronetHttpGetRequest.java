package com.kpu.cronet_test.cronet;

import android.app.Activity;
import android.util.Log;

import org.chromium.net.CronetEngine;
import org.chromium.net.CronetException;
import org.chromium.net.UrlRequest;
import org.chromium.net.UrlResponseInfo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CronetHttpGetRequest {

    private CronetEngine cronetEngine;

    private UrlRequest urlRequest;
    private static UrlRequest.Callback urlRequestCallback;

    private UrlResponseInfo urlResponseHeader;
    private boolean isDone=false;
    private byte[] urlResponse;

    private ExecutorService urlRequestExecutor;

    public CronetHttpGetRequest(Activity activity, String url){

        urlResponse=null;

        setCallback();

        cronetEngine=new CronetEngine.Builder(activity.getApplicationContext()).enableHttp2(true).enableQuic(true).enableBrotli(true).build();

        urlRequestExecutor=Executors.newCachedThreadPool();

        urlRequest=cronetEngine.newUrlRequestBuilder(url, urlRequestCallback, urlRequestExecutor).setHttpMethod("GET").build();

        urlRequest.start();

    }

    public byte[] getResponse(){

        while(true){

            if(isDone == true){

                break;

            }

        }

        return urlResponse;

    }

    public UrlResponseInfo getResponseInfo(){

        while(true){

            if(isDone == true){

                break;

            }

        }

        return urlResponseHeader;

    }

    private void setCallback(){

        urlRequestCallback = new UrlRequest.Callback() {

            public ByteArrayOutputStream mBytesReceived = new ByteArrayOutputStream();
            private WritableByteChannel mReceiveChannel = Channels.newChannel(mBytesReceived);

            @Override
            public void onRedirectReceived(UrlRequest urlRequest, UrlResponseInfo urlResponseInfo, String s) throws Exception {

                Log.i("TAG", "onRedirectReceived");
                urlRequest.followRedirect();
                urlResponseHeader = urlResponseInfo;

            }

            @Override
            public void onResponseStarted(UrlRequest urlRequest, UrlResponseInfo urlResponseInfo) throws Exception {

                Log.i("TAG", "onResponseStarted");
                urlRequest.read(ByteBuffer.allocateDirect(64 * 1024));

                urlResponseHeader = urlResponseInfo;

            }

            @Override
            public void onReadCompleted(UrlRequest urlRequest, UrlResponseInfo urlResponseInfo, ByteBuffer byteBuffer) throws Exception {

                Log.i("TAG", "onReadCompleted");
                byteBuffer.flip();

                try {

                    mReceiveChannel.write(byteBuffer);

                } catch (IOException e) {

                    e.printStackTrace();

                }

                byteBuffer.clear();
                urlRequest.read(byteBuffer);

                urlResponseHeader = urlResponseInfo;

            }

            @Override
            public void onSucceeded(UrlRequest urlRequest, UrlResponseInfo urlResponseInfo) {

                Log.i("TAG", "onSucceeded");
                Log.i("TAG", String.format("Request Completed, status code is %d, total received bytes is %d",
                        urlResponseInfo.getHttpStatusCode(), urlResponseInfo.getReceivedByteCount()));

                final String receivedData = mBytesReceived.toString();
                final String url = urlResponseInfo.getUrl();
                final byte[] responseBody = mBytesReceived.toByteArray();
                final String text = "Completed " + url + " (" + urlResponseInfo.getHttpStatusCode() + ")";

                Log.i("TAG", "text:" + text);
                Log.i("TAG", "receivedData:" + receivedData);

                urlResponse=responseBody;
                isDone=true;

                urlResponseHeader = urlResponseInfo;

                onCanceled(urlRequest, urlResponseInfo);

            }

            @Override
            public void onFailed(UrlRequest urlRequest, UrlResponseInfo urlResponseInfo, CronetException e) {

                Log.i("TAG", "onFailed");
                Log.i("TAG", "error is: %s" + e.getMessage());

                urlResponseHeader = urlResponseInfo;

                e.printStackTrace();

            }

            @Override
            public void onCanceled (UrlRequest request, UrlResponseInfo urlResponseInfo) {

                urlResponseHeader = urlResponseInfo;

            }

        };

    }

}
