package com.kpu.cronet_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.kpu.cronet_test.cronet.CronetHttpPostRequest;

import org.chromium.net.UrlResponseInfo;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    String httpResponse;

    TextView responseText;
    EditText url;
    Button submit;

    CronetHttpPostRequest httpRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        responseText=findViewById(R.id.responseText);
        url=findViewById(R.id.url);
        submit=findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                try{

                    Map<String, String> params = new HashMap<String, String>();

                    httpRequest=new CronetHttpPostRequest(MainActivity.this,url.getText().toString(), params);

                    httpResponse=new String(httpRequest.getResponse(), "UTF-8");

                    UrlResponseInfo httpReponseInfo = httpRequest.getResponseInfo();

                    Map<String, List<String>> headers = httpReponseInfo.getAllHeaders();

                    String headerAsString="";

                    for(Map.Entry<String, List<String>> e : headers.entrySet()){

                        for(String d : e.getValue()){
                            Log.i("HTTP Header " + e.getKey(), d);
                            headerAsString += (e.getKey() + ": " + d + '\n');
                        }

                    }

                    responseText.setText("negotiated protocol: " + httpReponseInfo.getNegotiatedProtocol() + "\n\n" + headerAsString + "\n" + httpResponse);

                }catch(UnsupportedEncodingException e){

                    e.printStackTrace();

                }

                System.gc();

            }

        });

    }
}
