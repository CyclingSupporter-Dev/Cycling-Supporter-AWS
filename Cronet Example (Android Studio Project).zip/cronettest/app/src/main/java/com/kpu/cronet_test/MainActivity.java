package com.kpu.cronet_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.chromium.net.CronetEngine;
import org.chromium.net.CronetException;
import org.chromium.net.UrlRequest;
import org.chromium.net.UrlResponseInfo;
import org.chromium.net.impl.CronetUrlRequest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.chromium.net.CronetEngine.Builder.HTTP_CACHE_IN_MEMORY;

public class MainActivity extends AppCompatActivity {

    public static CronetEngine cronetEngine;
    public static ExecutorService executor;
    private CronetUrlRequest cronetUrlRequest;

    protected TextView responseText;
    protected EditText url;
    protected Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cronetEngine=new CronetEngine.Builder(getApplicationContext()).enableHttp2(true).enableQuic(true).enableBrotli(true)
                .enableHttpCache(HTTP_CACHE_IN_MEMORY, 128 * 1000).build();

        executor = Executors.newCachedThreadPool();

        responseText=findViewById(R.id.responseText);
        url=findViewById(R.id.url);
        submit=findViewById(R.id.submit);

        responseText.setMovementMethod(new ScrollingMovementMethod());

        submit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                try{

                    String _url;

                    if(url.getText().toString().endsWith("/")){

                        _url=url.getText().toString().substring(0, url.getText().toString().length()-1);

                    }
                    else{

                        _url=url.getText().toString();

                    }

                    cronetUrlRequest=(CronetUrlRequest) cronetEngine.newUrlRequestBuilder(_url, new UrlRequest.Callback() {

                        private ByteArrayOutputStream mBytesReceived = new ByteArrayOutputStream();
                        private WritableByteChannel mReceiveChannel = Channels.newChannel(mBytesReceived);

                        @Override
                        public void onRedirectReceived(UrlRequest request, UrlResponseInfo info, String newLocationUrl) throws Exception {

                            request.followRedirect();

                        }

                        @Override
                        public void onResponseStarted(UrlRequest request, UrlResponseInfo info) throws Exception {

                            request.read(ByteBuffer.allocateDirect(64 * 1024));

                        }

                        @Override
                        public void onReadCompleted(UrlRequest request, UrlResponseInfo info, ByteBuffer byteBuffer) throws Exception {

                            byteBuffer.flip();

                            try {

                                mReceiveChannel.write(byteBuffer);

                            } catch (IOException e) {

                                e.printStackTrace();

                            }

                            byteBuffer.clear();
                            request.read(byteBuffer);

                        }

                        @Override
                        public void onSucceeded(UrlRequest request, UrlResponseInfo info) {

                            Map<String, List<String>> headers=info.getAllHeaders();

                            String headersAsString="";

                            for(Map.Entry<String, List<String>> e : headers.entrySet()){

                                for(String d : e.getValue()){
                                    Log.i("HTTP Header " + e.getKey(), d);
                                    headersAsString += (e.getKey() + ": " + d + '\n');
                                }

                            }

                            responseText.setText("negotiated-protocol: " + info.getNegotiatedProtocol() + "\n\n"
                                    + headersAsString + "\n" + mBytesReceived.toString());

                        }

                        @Override
                        public void onFailed(UrlRequest request, UrlResponseInfo info, CronetException error) {

                        }

                        @Override
                        public void onCanceled(UrlRequest request, UrlResponseInfo info){

                        }

                    }, executor).setHttpMethod("GET").build();

                    cronetUrlRequest.start();

                    cronetUrlRequest=null;

                    System.gc();

                }catch(Exception e) {

                    e.printStackTrace();

                    if (e instanceof CronetException) {

                        return;

                    }

                }

            }

        });

    }

}
